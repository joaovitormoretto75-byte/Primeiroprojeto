import { useState } from 'react';
import { ChevronUp, MessageCircle, Minus, Plus, Trash2, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { buildWhatsAppUrl, formatBRL } from '../data/menu';
import { SelectedOrderItem } from './MenuSection';

interface OrderBarProps {
  items: SelectedOrderItem[];
  onUpdateQty: (key: string, delta: number) => void;
  onClear: () => void;
}

export function OrderBar({ items, onUpdateQty, onClear }: OrderBarProps) {
  const [expanded, setExpanded] = useState(false);

  if (items.length === 0) {
    return null;
  }

  const totalCount = items.reduce((acc, item) => acc + item.quantity, 0);
  const totalValue = items.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);

  const lines = items.map(
    (i) => `• ${i.quantity}x ${i.name} (${i.sizeLabel}) — ${formatBRL(i.unitPrice * i.quantity)}`
  );
  const orderMessage = `Olá! Gostaria de fazer este pedido na Chocoitaly Sorvetes:\n\n${lines.join('\n')}\n\nTotal estimado: ${formatBRL(totalValue)}`;
  const waUrl = buildWhatsAppUrl(orderMessage);

  return (
    <div className="fixed bottom-4 inset-x-4 md:inset-x-auto md:right-8 md:w-[420px] z-50">
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="mb-2 bg-surface border border-border rounded-2xl p-5 shadow-2xl"
          >
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-border">
              <span className="font-display text-lg font-semibold text-foreground">
                Resumo do Pedido
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClear();
                    setExpanded(false);
                  }}
                  aria-label="Limpar pedido"
                  className="p-1.5 text-muted hover:text-danger transition-colors rounded-md"
                >
                  <Trash2 className="w-4 h-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => setExpanded(false)}
                  aria-label="Fechar resumo"
                  className="p-1.5 text-muted hover:text-foreground transition-colors rounded-md"
                >
                  <X className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </div>

            <ul className="space-y-3 max-h-56 overflow-y-auto pr-1">
              {items.map((item) => (
                <li
                  key={item.key}
                  className="flex items-center justify-between gap-3 text-sm"
                >
                  <div className="min-w-0">
                    <p className="font-medium text-foreground truncate">{item.name}</p>
                    <p className="text-xs text-muted tabular-nums">
                      {item.sizeLabel} · {formatBRL(item.unitPrice)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.key, -1)}
                      aria-label={`Remover uma unidade de ${item.name}`}
                      className="w-7 h-7 inline-flex items-center justify-center rounded-md border border-border text-muted hover:text-foreground transition-colors"
                    >
                      <Minus className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                    <span className="w-5 text-center tabular-nums font-medium text-foreground">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.key, 1)}
                      aria-label={`Adicionar uma unidade de ${item.name}`}
                      className="w-7 h-7 inline-flex items-center justify-center rounded-md border border-border text-muted hover:text-foreground transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Compact Floating Action Dock (<= 15% mobile height) */}
      <div className="bg-surface-elevated border border-border rounded-xl px-4 py-3 flex items-center justify-between gap-3 shadow-xl">
        <button
          type="button"
          onClick={() => setExpanded((prev) => !prev)}
          className="flex items-center gap-2 text-left min-w-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent rounded-sm"
        >
          <ChevronUp
            className={`w-4 h-4 text-accent transition-transform duration-200 shrink-0 ${
              expanded ? 'rotate-180' : ''
            }`}
            aria-hidden="true"
          />
          <div className="min-w-0">
            <p className="text-xs text-muted tabular-nums whitespace-nowrap">
              {totalCount} {totalCount === 1 ? 'item' : 'itens'}
            </p>
            <p className="text-sm font-semibold text-foreground tabular-nums whitespace-nowrap">
              {formatBRL(totalValue)}
            </p>
          </div>
        </button>

        <a
          href={waUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium bg-primary hover:bg-primary-hover text-primary-foreground rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
        >
          <MessageCircle className="w-4 h-4 text-accent shrink-0" aria-hidden="true" />
          <span>Conversar no WhatsApp</span>
        </a>
      </div>
    </div>
  );
}
