import { buildWhatsAppUrl, STORE_INFO } from '../data/menu';

export function Footer() {
  const waUrl = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Chocoitaly Sorvetes.'
  );

  return (
    <footer className="border-t border-border bg-background py-12 md:py-16">
      <div className="max-w-7xl mx-auto px-6 md:px-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
        <div>
          <p className="font-display text-xl font-semibold text-foreground mb-2">
            {STORE_INFO.fullName}
          </p>
          <p className="text-xs text-muted leading-relaxed">
            {STORE_INFO.address}
          </p>
        </div>

        <nav
          aria-label="Links do rodapé"
          className="flex flex-wrap items-center gap-6 text-sm text-muted"
        >
          <a href="#inicio" className="hover:text-foreground transition-colors whitespace-nowrap">
            Início
          </a>
          <a href="#cardapio" className="hover:text-foreground transition-colors whitespace-nowrap">
            Cardápio
          </a>
          <a href="#sobre" className="hover:text-foreground transition-colors whitespace-nowrap">
            Nossa Arte
          </a>
          <a href="#contato" className="hover:text-foreground transition-colors whitespace-nowrap">
            Contato
          </a>
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-accent hover:underline whitespace-nowrap"
          >
            WhatsApp
          </a>
        </nav>

        <p className="text-xs text-muted tabular-nums">
          © {new Date().getFullYear()} {STORE_INFO.fullName}
        </p>
      </div>
    </footer>
  );
}
