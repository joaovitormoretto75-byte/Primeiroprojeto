import { useState } from 'react';
import { Check, MessageCircle, Plus } from 'lucide-react';
import { motion } from 'motion/react';
import {
  buildWhatsAppUrl,
  formatBRL,
  MENU_ITEMS,
  MenuCategory,
  MenuItem,
} from '../data/menu';
import { ResilientImage } from './ResilientImage';

export interface SelectedOrderItem {
  key: string;
  itemId: string;
  name: string;
  sizeLabel: string;
  unitPrice: number;
  quantity: number;
}

interface MenuSectionProps {
  onAddItem: (entry: Omit<SelectedOrderItem, 'quantity'>) => void;
}

const FILTER_OPTIONS: { id: MenuCategory; label: string }[] = [
  { id: 'todos', label: 'Todos' },
  { id: 'acais', label: 'Açaís' },
  { id: 'sorvetes', label: 'Sorvetes' },
];

export function MenuSection({ onAddItem }: MenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState<MenuCategory>('todos');
  const [selectedSizes, setSelectedSizes] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    for (const item of MENU_ITEMS) {
      initial[item.id] = item.sizes.length > 1 ? 1 : 0;
    }
    return initial;
  });
  const [justAddedKey, setJustAddedKey] = useState<string | null>(null);

  const visibleItems =
    activeCategory === 'todos'
      ? MENU_ITEMS
      : MENU_ITEMS.filter((item) => item.category === activeCategory);

  function handleSelectSize(itemId: string, sizeIndex: number) {
    setSelectedSizes((prev) => ({ ...prev, [itemId]: sizeIndex }));
  }

  function handleAdd(item: MenuItem) {
    const sizeIdx = selectedSizes[item.id] ?? 0;
    const size = item.sizes[sizeIdx] ?? item.sizes[0];
    const key = `${item.id}::${size.label}`;

    onAddItem({
      key,
      itemId: item.id,
      name: item.name,
      sizeLabel: size.label,
      unitPrice: size.price,
    });

    setJustAddedKey(key);
    window.setTimeout(() => {
      setJustAddedKey((current) => (current === key ? null : current));
    }, 1200);
  }

  return (
    <section id="cardapio" className="py-24 md:py-32 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Header + Interactive Digital Menu Filter */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-14"
        >
          <div className="max-w-xl">
            <p className="text-xs tracking-[0.18em] uppercase text-accent font-medium mb-3">
              Cardápio Digital
            </p>
            <h2 className="font-display text-[clamp(2rem,3.5vw,3rem)] font-semibold leading-[1.1] tracking-tight text-foreground">
              Três criações, preparo na hora.
            </h2>
          </div>

          <div
            role="group"
            aria-label="Filtrar cardápio por categoria"
            className="inline-flex items-center gap-1 p-1 bg-surface border border-border rounded-lg self-start md:self-auto"
          >
            {FILTER_OPTIONS.map((option) => {
              const isActive = activeCategory === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setActiveCategory(option.id)}
                  aria-pressed={isActive}
                  className={`px-4 py-2 text-xs md:text-sm font-medium rounded-md transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ${
                    isActive
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted hover:text-foreground'
                  }`}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </motion.div>

        {/* 3-Column Product Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {visibleItems.map((item, idx) => {
            const sizeIdx = selectedSizes[item.id] ?? 0;
            const activeSize = item.sizes[sizeIdx] ?? item.sizes[0];
            const itemKey = `${item.id}::${activeSize.label}`;
            const wasJustAdded = justAddedKey === itemKey;
            const directWaUrl = buildWhatsAppUrl(
              `Olá! Gostaria de pedir: 1x ${item.name} (${activeSize.label}) — ${formatBRL(activeSize.price)}.`
            );

            return (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{
                  duration: 0.6,
                  delay: idx * 0.08,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="group flex flex-col bg-surface border border-border rounded-2xl overflow-hidden transition-transform duration-200 hover:-translate-y-0.5"
              >
                {/* 4:3 Editorial Product Photography */}
                <div className="aspect-[4/3] w-full overflow-hidden bg-surface-elevated">
                  <ResilientImage
                    src={item.image}
                    alt={item.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                  />
                </div>

                {/* Product Body */}
                <div className="p-6 md:p-7 flex flex-col flex-1">
                  <p className="text-xs text-muted tracking-wide mb-2">
                    {item.kicker}
                  </p>

                  <div className="flex items-baseline justify-between gap-4 mb-3">
                    <h3 className="font-display text-xl font-semibold text-foreground leading-snug">
                      {item.name}
                    </h3>
                    <span className="text-base font-semibold text-accent tabular-nums whitespace-nowrap shrink-0">
                      {formatBRL(activeSize.price)}
                    </span>
                  </div>

                  <p className="text-sm leading-relaxed text-muted mb-6 flex-1">
                    {item.description}
                  </p>

                  {/* Size Selector */}
                  <div className="mb-5">
                    <span className="sr-only">Selecione o tamanho</span>
                    <div className="grid grid-cols-3 gap-2">
                      {item.sizes.map((size, sIdx) => {
                        const selected = sIdx === sizeIdx;
                        return (
                          <button
                            key={size.label}
                            type="button"
                            onClick={() => handleSelectSize(item.id, sIdx)}
                            aria-pressed={selected}
                            className={`py-2 px-2 text-xs font-medium rounded-md border transition-colors duration-150 tabular-nums whitespace-nowrap truncate focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ${
                              selected
                                ? 'bg-surface-elevated border-accent text-foreground'
                                : 'bg-background/40 border-border text-muted hover:text-foreground'
                            }`}
                          >
                            {size.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Card Actions */}
                  <div className="flex items-center gap-3 pt-4 border-t border-border">
                    <button
                      type="button"
                      onClick={() => handleAdd(item)}
                      className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg bg-primary hover:bg-primary-hover text-primary-foreground transition-colors duration-200 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                    >
                      {wasJustAdded ? (
                        <>
                          <Check className="w-4 h-4 text-accent shrink-0" aria-hidden="true" />
                          <span>Adicionado</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4 text-accent shrink-0" aria-hidden="true" />
                          <span>Adicionar ao pedido</span>
                        </>
                      )}
                    </button>

                    <a
                      href={directWaUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Pedir ${item.name} no WhatsApp`}
                      title="Pedir direto no WhatsApp"
                      className="inline-flex items-center justify-center w-10 h-10 rounded-lg border border-border text-muted hover:text-accent hover:border-accent transition-colors duration-200 shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                    >
                      <MessageCircle className="w-4 h-4" aria-hidden="true" />
                    </a>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
