import { FormEvent, useState } from 'react';
import { CheckCircle2, MapPin, MessageCircle, Phone } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl, STORE_INFO } from '../data/menu';

export function ContactSection() {
  const [name, setName] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [preparedUrl, setPreparedUrl] = useState<string | null>(null);

  const directWaUrl = buildWhatsAppUrl(
    'Olá! Gostaria de conversar e fazer um pedido na Chocoitaly Sorvetes.'
  );

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedNote = note.trim();

    if (trimmedName.length < 2) {
      setError('Informe seu nome para continuarmos no WhatsApp.');
      return;
    }
    if (trimmedNote.length < 4) {
      setError('Escreva seu pedido ou mensagem com pelo menos 4 caracteres.');
      return;
    }

    setError('');
    const message = `Olá, me chamo ${trimmedName}. ${trimmedNote}`;
    const waUrl = buildWhatsAppUrl(message);
    setPreparedUrl(waUrl);
  }

  return (
    <section id="contato" className="py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Direct Store Contact Info */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs tracking-[0.18em] uppercase text-accent font-medium mb-4">
              Contato
            </p>
            <h2 className="font-display text-[clamp(2rem,3.5vw,3rem)] font-semibold leading-[1.1] tracking-tight text-foreground mb-6">
              Peça direto pelo WhatsApp.
            </h2>
            <p className="text-base leading-relaxed text-muted mb-10 max-w-md">
              Atendimento rápido em Cafelândia para retirada no balcão ou pedido personalizado.
            </p>

            <div className="space-y-6 border-t border-border pt-8">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-accent shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted mb-1">
                    Endereço
                  </p>
                  <p className="text-sm md:text-base text-foreground leading-relaxed">
                    {STORE_INFO.address}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 text-accent shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted mb-1">
                    Telefone & WhatsApp
                  </p>
                  <a
                    href={`tel:+${STORE_INFO.phoneRaw}`}
                    className="text-sm md:text-base text-foreground hover:text-accent transition-colors tabular-nums"
                  >
                    {STORE_INFO.phoneDisplay}
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a
                href={directWaUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm md:text-base font-medium text-primary-foreground bg-primary hover:bg-primary-hover rounded-lg transition-colors duration-200 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                <MessageCircle className="w-4 h-4 text-accent shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Minimalist Validated Quick Message Builder */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-surface border border-border rounded-2xl p-7 md:p-10"
          >
            <h3 className="font-display text-2xl font-semibold text-foreground mb-2">
              Envie seu pedido
            </h3>
            <p className="text-sm text-muted mb-8">
              Preencha abaixo para abrir sua conversa já com o pedido pronto.
            </p>

            {preparedUrl ? (
              <div className="py-6 space-y-5">
                <div className="flex items-start gap-3 text-foreground">
                  <CheckCircle2 className="w-5 h-5 text-accent shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <p className="font-medium text-base">Mensagem pronta para envio</p>
                    <p className="text-sm text-muted mt-1">
                      Clique no botão abaixo para abrir o WhatsApp da {STORE_INFO.fullName}.
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <a
                    href={preparedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium bg-primary hover:bg-primary-hover text-primary-foreground rounded-lg transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                  >
                    <MessageCircle className="w-4 h-4 text-accent" aria-hidden="true" />
                    <span>Conversar no WhatsApp</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => {
                      setPreparedUrl(null);
                      setName('');
                      setNote('');
                    }}
                    className="px-4 py-3 text-sm font-medium text-muted hover:text-foreground transition-colors whitespace-nowrap"
                  >
                    Editar mensagem
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-6">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-sm font-medium text-foreground mb-2"
                  >
                    Seu nome
                  </label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="Ex.: Mariana Souza"
                    className="w-full px-4 py-3 text-sm bg-background border border-border rounded-lg text-foreground placeholder:text-muted/60 focus:outline-none focus:border-accent transition-colors"
                  />
                </div>

                <div>
                  <label
                    htmlFor="contact-note"
                    className="block text-sm font-medium text-foreground mb-2"
                  >
                    O que você gostaria de pedir?
                  </label>
                  <textarea
                    id="contact-note"
                    name="note"
                    rows={4}
                    required
                    value={note}
                    onChange={(e) => {
                      setNote(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="Ex.: 1 Chocoitaly Signature 500 ml e 1 Açaí Puro 300 ml para retirada."
                    className="w-full px-4 py-3 text-sm bg-background border border-border rounded-lg text-foreground placeholder:text-muted/60 focus:outline-none focus:border-accent transition-colors resize-none"
                  />
                </div>

                {error && (
                  <p role="alert" className="text-sm text-danger">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-medium bg-primary hover:bg-primary-hover text-primary-foreground rounded-lg transition-colors duration-200 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <MessageCircle className="w-4 h-4 text-accent shrink-0" aria-hidden="true" />
                  <span>Preparar pedido no WhatsApp</span>
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
