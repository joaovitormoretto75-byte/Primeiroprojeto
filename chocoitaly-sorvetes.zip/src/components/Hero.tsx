import { ArrowDown, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl, HERO_ASSET, STORE_INFO } from '../data/menu';
import { ResilientImage } from './ResilientImage';

export function Hero() {
  const waUrl = buildWhatsAppUrl(
    'Olá! Quero conhecer os sabores e fazer um pedido na Chocoitaly Sorvetes.'
  );

  return (
    <section
      id="inicio"
      className="relative pt-12 pb-20 md:pt-20 md:pb-28 border-b border-border overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-stretch">
          {/* Editorial Copy Column */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-center"
          >
            <p className="text-xs tracking-[0.18em] uppercase text-accent font-medium mb-6">
              {STORE_INFO.city}
            </p>

            <h1 className="font-display text-[clamp(2.5rem,5vw,4.5rem)] font-semibold leading-[1.05] tracking-tight text-foreground mb-6">
              Açaí puro e gelato italiano.
            </h1>

            <p className="text-base md:text-lg leading-relaxed text-muted max-w-md mb-10">
              Cremosidade artesanal preparada na hora na Av. Mal. Lott, com polpa selecionada e chocolate de verdade.
            </p>

            <div className="flex flex-wrap items-center gap-6">
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm md:text-base font-medium text-primary-foreground bg-primary hover:bg-primary-hover rounded-lg transition-all duration-200 hover:-translate-y-0.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                <MessageCircle className="w-4 h-4 text-accent shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>

              <a
                href="#cardapio"
                className="inline-flex items-center gap-2 py-2 text-sm font-medium text-foreground/90 hover:text-accent transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent rounded-sm"
              >
                <span>Ver cardápio</span>
                <ArrowDown className="w-4 h-4 text-accent" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Dominant Focal Visual Column */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex"
          >
            <div className="relative w-full aspect-[4/3] lg:aspect-auto lg:min-h-[480px] rounded-2xl overflow-hidden border border-border bg-surface">
              <ResilientImage
                src={HERO_ASSET.src}
                alt={HERO_ASSET.alt}
                loading="eager"
                fetchPriority="high"
                className="w-full h-full object-cover"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background/50 via-transparent to-transparent"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
