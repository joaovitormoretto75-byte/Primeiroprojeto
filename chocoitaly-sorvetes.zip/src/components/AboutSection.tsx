import { motion } from 'motion/react';
import { ABOUT_ASSET, CRAFT_STATS } from '../data/menu';
import { ResilientImage } from './ResilientImage';

export function AboutSection() {
  return (
    <section id="sobre" className="py-24 md:py-32 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Arched Editorial Portrait */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="aspect-[3/4] max-w-md mx-auto lg:mx-0 overflow-hidden rounded-t-[10rem] rounded-b-2xl border border-border bg-surface">
              <ResilientImage
                src={ABOUT_ASSET.src}
                alt={ABOUT_ASSET.alt}
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          {/* Right Column: Narrative & Culinary Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.65, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col justify-center"
          >
            <p className="text-xs tracking-[0.18em] uppercase text-accent font-medium mb-4">
              Nossa Arte
            </p>

            <h2 className="font-display text-[clamp(2rem,3.6vw,3.125rem)] font-semibold leading-[1.1] tracking-tight text-foreground mb-6">
              Sabor que respeita o tempo.
            </h2>

            <p className="text-base md:text-lg leading-relaxed text-muted max-w-xl mb-12">
              Na Chocoitaly, cada tigela une a força do açaí amazônico ao preparo delicado do gelato de chocolate italiano. Frutas cortadas na hora e textura aveludada sem atalhos.
            </p>

            {/* Hairline-separated culinary metrics (zero boxed cards-in-cards) */}
            <div className="border-t border-border divide-y divide-border">
              {CRAFT_STATS.map((stat) => (
                <div
                  key={stat.label}
                  className="py-5 grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-6 items-baseline"
                >
                  <span className="sm:col-span-3 font-display text-3xl md:text-4xl font-semibold text-accent tabular-nums">
                    {stat.value}
                  </span>
                  <div className="sm:col-span-9">
                    <h3 className="text-sm font-semibold text-foreground mb-1">
                      {stat.label}
                    </h3>
                    <p className="text-sm text-muted leading-relaxed">
                      {stat.detail}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
