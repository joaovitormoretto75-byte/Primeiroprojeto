export type MenuCategory = 'todos' | 'acais' | 'sorvetes';

export interface ProductSize {
  label: string;
  price: number;
}

export interface MenuItem {
  id: string;
  category: Exclude<MenuCategory, 'todos'>;
  kicker: string;
  name: string;
  description: string;
  image: string;
  alt: string;
  sizes: ProductSize[];
}

export const STORE_INFO = {
  brand: 'Chocoitaly',
  fullName: 'Chocoitaly sorvetes',
  city: 'Cafelândia · PR',
  address: 'Av. Mal. Lott, 1-117 - Centro, Cafelândia - PR, 85415-000',
  phoneDisplay: '+55 45 3241-2524',
  phoneRaw: '554532412524',
} as const;

export function buildWhatsAppUrl(message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${STORE_INFO.phoneRaw}?text=${encoded}`;
}

export function formatBRL(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

export const HERO_ASSET = {
  src: '/src/assets/images/hero_acai_chocoitaly_1795171714901.jpg',
  alt: 'Tigela artesanal de açaí puro Chocoitaly com morangos frescos, banana, granola e calda de chocolate italiano',
};

export const ABOUT_ASSET = {
  src: '/src/assets/images/sobre_acaiteria_artesanal_1795171714452.jpg',
  alt: 'Atendente da Chocoitaly preparando tigela de açaí artesanal com frutas frescas no balcão em Cafelândia',
};

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'acai-amazonia',
    category: 'acais',
    kicker: 'Linha Clássica · Polpa Pura',
    name: 'Açaí Puro da Amazônia',
    description: 'Creme intenso batido na hora, acompanhado de banana fresca, granola tostada e fio de mel.',
    image: '/src/assets/images/cardapio_acai_amazonia_1795171714333.jpg',
    alt: 'Tigela de Açaí Puro da Amazônia com rodelas de banana, granola dourada, chia e mel',
    sizes: [
      { label: '300 ml', price: 18.0 },
      { label: '500 ml', price: 24.0 },
      { label: '700 ml', price: 31.0 },
    ],
  },
  {
    id: 'chocoitaly-signature',
    category: 'acais',
    kicker: 'Assinatura da Casa · Fusão',
    name: 'Chocoitaly Signature',
    description: 'Açaí cremoso com bola de gelato de chocolate italiano, avelã crocante e morangos selecionados.',
    image: '/src/assets/images/cardapio_acai_chocoitaly_1795171714412.jpg',
    alt: 'Chocoitaly Signature com açaí roxo profundo, bola de gelato de chocolate italiano, avelãs e morangos',
    sizes: [
      { label: '300 ml', price: 22.0 },
      { label: '500 ml', price: 29.0 },
      { label: '700 ml', price: 36.0 },
    ],
  },
  {
    id: 'gelato-tropical',
    category: 'sorvetes',
    kicker: 'Gelateria · Sazonal',
    name: 'Gelato & Frutas Tropicais',
    description: 'Dupla de gelato meio amargo italiano e sorbet de maracujá fresco com lascas de cacau.',
    image: '/src/assets/images/cardapio_gelato_tropical_1795171713745.jpg',
    alt: 'Taça escura com duas bolas de gelato artesanal de chocolate italiano e sorbet de maracujá com frutas vermelhas',
    sizes: [
      { label: '2 bolas', price: 16.0 },
      { label: '3 bolas', price: 22.0 },
      { label: '500 ml', price: 34.0 },
    ],
  },
];

export const CRAFT_STATS = [
  {
    value: '100%',
    label: 'Polpa selecionada',
    detail: 'Sem xarope artificial na base do nosso açaí.',
  },
  {
    value: '-18 °C',
    label: 'Ponto de cremosidade',
    detail: 'Temperatura controlada para textura firme e aveludada.',
  },
  {
    value: '03',
    label: 'Tamanhos sob medida',
    detail: 'Porções pensadas para o seu momento do dia.',
  },
] as const;
