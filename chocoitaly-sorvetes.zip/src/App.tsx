import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { MenuSection, SelectedOrderItem } from './components/MenuSection';
import { Navbar } from './components/Navbar';
import { OrderBar } from './components/OrderBar';

export default function App() {
  const [orderItems, setOrderItems] = useState<SelectedOrderItem[]>([]);

  function handleAddItem(entry: Omit<SelectedOrderItem, 'quantity'>) {
    setOrderItems((prev) => {
      const existing = prev.find((item) => item.key === entry.key);
      if (existing) {
        return prev.map((item) =>
          item.key === entry.key
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...entry, quantity: 1 }];
    });
  }

  function handleUpdateQty(key: string, delta: number) {
    setOrderItems((prev) =>
      prev
        .map((item) =>
          item.key === key
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }

  function handleClearOrder() {
    setOrderItems([]);
  }

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-background text-foreground selection:bg-primary selection:text-primary-foreground">
        <Navbar />
        <main className="flex-1">
          <Hero />
          <MenuSection onAddItem={handleAddItem} />
          <AboutSection />
          <ContactSection />
        </main>
        <Footer />
        <OrderBar
          items={orderItems}
          onUpdateQty={handleUpdateQty}
          onClear={handleClearOrder}
        />
      </div>
    </MotionConfig>
  );
}
